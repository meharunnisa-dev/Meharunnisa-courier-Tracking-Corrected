# Meharunnisa's Courier & Parcel Tracking Management System

## Database connection (important)
The project reads MySQL settings from the `.env` file in the same folder as `app.js`.
The included local `.env` is configured for a MySQL account named `root` and database `courier_management`.
If your MySQL password changes later, edit only `DB_PASSWORD` in `.env`, save, stop the server with Ctrl+C, and run `npm start` again.

**Security:** This ZIP includes your local database password because you requested a ready-to-run package. Do not upload this ZIP or `.env` publicly, and change the password if you share the ZIP with anyone. `.env` is ignored by Git.

## Setup in Windows / VS Code
1. Extract this ZIP.
2. Open the extracted `Meharunnisa-Courier-Tracking` folder in VS Code (the folder containing `app.js` and `package.json`).
3. Start MySQL Server / MySQL80 service.
4. In MySQL Workbench, open `sql/courier_management.sql` and execute it. It creates/uses `courier_management` and creates the three required tables if they do not exist.
5. In the VS Code terminal, run `npm install`.
6. Run `npm start`.
7. Open `http://localhost:3000/api/health` first. It should show `success: true` and counts for customers, parcels, and tracking.
8. Open `http://localhost:3000` to use the website.

## Important: showing your existing Workbench records
This website reads from exactly this schema:
- Database: `courier_management`
- Tables: `customers`, `parcels`, `tracking`

In Workbench, run:
```sql
SELECT DATABASE();
SHOW TABLES;
SELECT COUNT(*) FROM customers;
SELECT COUNT(*) FROM parcels;
SELECT COUNT(*) FROM tracking;
```
If your existing records are in a different database/schema, change `DB_NAME` in `.env` to that exact database name and restart the server. The table names and columns must match the supplied SQL schema. `CREATE TABLE IF NOT EXISTS` does not rename or change an older/different table structure.

## Pages and features
- Home dashboard
- Customer list, add, view, update and delete
- Book parcel and parcel list
- Track parcel with history
- Tracking status updates
- About Meharunnisa

Do not use Live Server or open HTML files directly. Use `npm start` and `http://localhost:3000` so the API routes work.


## Troubleshooting: Workbench data is not visible
1. Start MySQL Server, then start this project with `npm start` from the folder containing `app.js`.
2. Open `http://localhost:3000/api/health`. `success: true` means the three required tables exist and are readable.
3. Open `http://localhost:3000/api/db-info` to see which database is selected and the table names it contains. This diagnostic does not expose customer records.
4. If the selected database is not the one containing your Workbench records, change `DB_NAME` in `.env` to the exact schema name and restart `npm start`.
5. This project expects tables named `customers`, `parcels`, and `tracking`, with the columns defined in `sql/courier_management.sql`. If your Workbench tables use different names or columns, they must be mapped to this project's API queries. Do not run the supplied CREATE TABLE script over an existing project database unless you intend to create these tables.
6. Do not open the HTML files with Live Server. Use `http://localhost:3000`.

## About page photo
The uploaded ZIP did not contain the portrait image. The About page now has a packaged placeholder and will automatically use `public/images/meharunnisa.jpg` when you add your actual photo with that exact filename.
