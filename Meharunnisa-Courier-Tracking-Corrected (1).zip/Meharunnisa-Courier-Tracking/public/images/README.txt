ABOUT PAGE PHOTO
The uploaded ZIP did not contain your portrait photo, so this folder includes a temporary placeholder.
To show your real photo, copy your photo into this folder and name it meharunnisa.jpg.
The About page is configured to load images/meharunnisa.jpg first and use the placeholder if it is absent.
