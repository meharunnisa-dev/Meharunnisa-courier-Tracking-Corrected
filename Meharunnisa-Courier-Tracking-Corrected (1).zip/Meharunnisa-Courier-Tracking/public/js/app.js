const $=s=>document.querySelector(s);
const api=async(url,opts={})=>{const r=await fetch(url,{headers:{"Content-Type":"application/json"},...opts});const d=await r.json();if(!r.ok)throw new Error(d.message||"Request failed");return d};
const msg=(el,text,type="info")=>{if(!el)return;el.textContent=text;el.className="message "+type;};
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
document.querySelector(".menu-toggle")?.addEventListener("click",()=>$(".nav-links")?.classList.toggle("open"));
document.querySelectorAll("[data-year]").forEach(e=>e.textContent=new Date().getFullYear());

async function loadCustomers(selectId,selected=""){
 const sel=$(selectId);if(!sel)return;
 const rows=await api("/api/customers");
 sel.innerHTML='<option value="">Select customer</option>'+rows.map(c=>`<option value="${c.customer_id}" ${String(c.customer_id)===String(selected)?"selected":""}>${esc(c.customer_name)} — ${esc(c.phone)}</option>`).join("");
 return rows;
}
const customerForm=$("#customerForm");
if(customerForm)customerForm.addEventListener("submit",async e=>{
 e.preventDefault();const data=Object.fromEntries(new FormData(customerForm));const id=customerForm.dataset.id;
 try{const r=await api(id?`/api/customers/${id}`:"/api/customers",{method:id?"PUT":"POST",body:JSON.stringify(data)});msg($("#message"),r.message,"success");if(!id)customerForm.reset();}
 catch(err){msg($("#message"),err.message,"error");}
});
const customerTable=$("#customerRows");
if(customerTable){
 async function renderCustomers(){try{const rows=await api("/api/customers");customerTable.innerHTML=rows.length?rows.map(c=>`<tr><td>${c.customer_id}</td><td><b>${esc(c.customer_name)}</b></td><td>${esc(c.phone)}</td><td>${esc(c.email||"-")}</td><td>${esc(c.city||"-")}</td><td><div class="table-actions"><a class="view-action" href="view-customer.html?id=${c.customer_id}">View</a><a class="edit-action" href="update-customer.html?id=${c.customer_id}">Edit</a><button class="delete-action" data-delete="${c.customer_id}">Delete</button></div></td></tr>`).join(""):'<tr><td colspan="6" class="empty">No customers added yet.</td></tr>';}catch(e){customerTable.innerHTML=`<tr><td colspan="6">${esc(e.message)}</td></tr>`;}}
 customerTable.addEventListener("click",async e=>{const b=e.target.closest("[data-delete]");if(!b)return;if(!confirm("Delete this customer? Customers with existing parcels cannot be deleted."))return;try{const r=await api(`/api/customers/${b.dataset.delete}`,{method:"DELETE"});msg($("#message"),r.message,"success");renderCustomers();}catch(err){msg($("#message"),err.message,"error");}});renderCustomers();
}
const custSelect=$("#customer_id");
if(custSelect)loadCustomers("#customer_id").catch(e=>msg($("#message"),e.message,"error"));
const editForm=$("#editCustomerForm");
if(editForm){(async()=>{try{const id=new URLSearchParams(location.search).get("id");if(!id)throw Error("Customer ID is missing.");const c=await api(`/api/customers/${id}`);for(const k of ["customer_name","phone","email","address","city"])editForm.elements[k].value=c[k]||"";editForm.dataset.id=id;}catch(e){msg($("#message"),e.message,"error");}})();}
const viewCustomer=$("#customerDetails");
if(viewCustomer){(async()=>{try{const id=new URLSearchParams(location.search).get("id");const c=await api(`/api/customers/${id}`);viewCustomer.innerHTML=`<div class="form-grid">${[["Customer ID",c.customer_id],["Customer Name",c.customer_name],["Phone",c.phone],["Email",c.email||"-"],["City",c.city||"-"],["Address",c.address]].map(([a,b])=>`<div class="form-group"><label>${a}</label><input readonly value="${esc(b)}"></div>`).join("")}</div>`;}catch(e){msg($("#message"),e.message,"error");}})();}
const bookForm=$("#bookParcelForm");
if(bookForm){bookForm.addEventListener("submit",async e=>{e.preventDefault();try{const d=Object.fromEntries(new FormData(bookForm));const r=await api("/api/parcels",{method:"POST",body:JSON.stringify(d)});$("#bookingResult").innerHTML=`<div class="message success">Parcel booked! Tracking number: <b>${esc(r.tracking_number)}</b> &nbsp; <a href="track.html?number=${encodeURIComponent(r.tracking_number)}">Track now</a></div>`;bookForm.reset();}catch(e){msg($("#message"),e.message,"error");}});}
const parcelRows=$("#parcelRows");
if(parcelRows){(async()=>{try{const rows=await api("/api/parcels");parcelRows.innerHTML=rows.length?rows.map(p=>`<tr><td><b>${esc(p.tracking_number)}</b></td><td>${esc(p.customer_name)}</td><td>${esc(p.receiver_name)}</td><td>${esc(p.origin)} → ${esc(p.destination)}</td><td><span class="badge">${esc(p.current_status)}</span></td><td><a class="view-action" href="track.html?number=${encodeURIComponent(p.tracking_number)}">Track</a></td></tr>`).join(""):'<tr><td colspan="6" class="empty">No parcels booked yet.</td></tr>';}catch(e){parcelRows.innerHTML=`<tr><td colspan="6">${esc(e.message)}</td></tr>`;}})();}
const trackForm=$("#trackForm");
async function track(number){const target=$("#trackResult");target.innerHTML="Loading parcel information...";try{const d=await api(`/api/parcels/${encodeURIComponent(number)}`);const p=d.parcel;target.innerHTML=`<div class="tracking-card"><div class="tracking-head"><div><small class="muted">TRACKING NUMBER</small><br><strong>${esc(p.tracking_number)}</strong></div><span class="badge">${esc(p.current_status)}</span></div><div class="tracking-route"><div><small>ORIGIN</small><b>${esc(p.origin)}</b></div><span>➜</span><div><small>DESTINATION</small><b>${esc(p.destination)}</b></div></div><p class="muted">Sender: <b>${esc(p.customer_name)}</b> &nbsp; | &nbsp; Receiver: <b>${esc(p.receiver_name)}</b></p><h3 style="margin:18px 0 12px;color:#173653">Tracking history</h3><div class="timeline">${d.events.map(t=>`<div class="timeline-item"><b>${esc(t.status)}</b><p>${esc(t.remarks||"")}</p><small>${esc(t.current_location)} · ${new Date(t.update_time).toLocaleString()}</small></div>`).join("")}</div></div>`;}catch(e){msg(target,e.message,"error");}}
if(trackForm){trackForm.addEventListener("submit",e=>{e.preventDefault();track(new FormData(trackForm).get("tracking_number"));});const n=new URLSearchParams(location.search).get("number");if(n){trackForm.elements.tracking_number.value=n;track(n);}}
const trackingForm=$("#trackingForm");
if(trackingForm){(async()=>{try{const rows=await api("/api/parcels");const sel=trackingForm.elements.parcel_id;sel.innerHTML='<option value="">Select parcel</option>'+rows.map(p=>`<option value="${p.parcel_id}">${esc(p.tracking_number)} — ${esc(p.customer_name)} to ${esc(p.receiver_name)}</option>`).join("");}catch(e){msg($("#message"),e.message,"error");}})();trackingForm.addEventListener("submit",async e=>{e.preventDefault();try{const d=Object.fromEntries(new FormData(trackingForm));const r=await api("/api/tracking",{method:"POST",body:JSON.stringify(d)});msg($("#message"),r.message,"success");trackingForm.reset();}catch(e){msg($("#message"),e.message,"error");}});}
const stats=$("#stats");
if(stats){(async()=>{try{const s=await api("/api/summary");stats.innerHTML=[["Customers",s.customers],["Total Parcels",s.parcels],["Delivered",s.delivered],["Active Shipments",s.active]].map(([a,b])=>`<div class="stat-card"><span>${a}</span><strong>${b}</strong></div>`).join("");}catch(e){stats.innerHTML=`<p>${esc(e.message)}</p>`;}})();}
