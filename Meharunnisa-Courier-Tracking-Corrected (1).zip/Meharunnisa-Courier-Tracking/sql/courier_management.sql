CREATE DATABASE IF NOT EXISTS courier_management;
USE courier_management;

-- TABLE 1: CUSTOMERS (people who book/send parcels)
CREATE TABLE IF NOT EXISTS customers (
  customer_id INT AUTO_INCREMENT PRIMARY KEY,
  customer_name VARCHAR(120) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  email VARCHAR(150),
  address TEXT NOT NULL,
  city VARCHAR(80),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- TABLE 2: PARCELS (each parcel belongs to one customer)
CREATE TABLE IF NOT EXISTS parcels (
  parcel_id INT AUTO_INCREMENT PRIMARY KEY,
  tracking_number VARCHAR(30) NOT NULL UNIQUE,
  customer_id INT NOT NULL,
  receiver_name VARCHAR(120) NOT NULL,
  receiver_phone VARCHAR(20) NOT NULL,
  pickup_address TEXT NOT NULL,
  delivery_address TEXT NOT NULL,
  origin VARCHAR(80) NOT NULL,
  destination VARCHAR(80) NOT NULL,
  parcel_type VARCHAR(50) DEFAULT 'Package',
  weight DECIMAL(8,2) DEFAULT 0.50,
  amount DECIMAL(10,2) DEFAULT 0.00,
  current_status ENUM('Booked','Picked Up','In Transit','Out for Delivery','Delivered','On Hold','Cancelled') DEFAULT 'Booked',
  booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_parcel_customer FOREIGN KEY (customer_id)
    REFERENCES customers(customer_id) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- TABLE 3: TRACKING (each update belongs to one parcel)
CREATE TABLE IF NOT EXISTS tracking (
  tracking_id INT AUTO_INCREMENT PRIMARY KEY,
  parcel_id INT NOT NULL,
  status VARCHAR(50) NOT NULL,
  current_location VARCHAR(120) NOT NULL,
  remarks VARCHAR(500),
  update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_tracking_parcel FOREIGN KEY (parcel_id)
    REFERENCES parcels(parcel_id) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Add customers through the website's Add Customer page.
-- Then book parcels and update their tracking from the Tracking Updates page.
