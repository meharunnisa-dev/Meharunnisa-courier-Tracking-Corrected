require("dotenv").config({ path: require("path").join(__dirname, ".env") });

const express = require("express");
const path = require("path");
const mysql = require("mysql2/promise");

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

const db = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD ?? "",
  database: process.env.DB_NAME || "courier_management",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

const wrap = fn => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

const validId = v =>
  Number.isSafeInteger(Number(v)) && Number(v) > 0;

// Connection + schema check. Open this URL in the browser to diagnose MySQL.
app.get("/api/health", wrap(async (req, res) => {
  await db.query("SELECT 1");
  const [tables] = await db.query(
    `SELECT TABLE_NAME FROM information_schema.tables
     WHERE table_schema = DATABASE()
       AND TABLE_NAME IN ('customers', 'parcels', 'tracking')`
  );
  const found = tables.map(t => t.TABLE_NAME);
  const missing = ["customers", "parcels", "tracking"].filter(t => !found.includes(t));

  if (missing.length) {
    return res.status(503).json({
      success: false,
      message: `Connected to database '${process.env.DB_NAME || "courier_management"}', but these tables are missing: ${missing.join(", ")}. Run sql/courier_management.sql in MySQL Workbench.`,
      database: process.env.DB_NAME || "courier_management",
      tablesFound: found,
      missingTables: missing
    });
  }

  const [[customers]] = await db.query("SELECT COUNT(*) AS total FROM customers");
  const [[parcels]] = await db.query("SELECT COUNT(*) AS total FROM parcels");
  const [[tracking]] = await db.query("SELECT COUNT(*) AS total FROM tracking");

  res.json({
    success: true,
    message: "MySQL connected and all required tables are available.",
    database: process.env.DB_NAME || "courier_management",
    counts: {
      customers: customers.total,
      parcels: parcels.total,
      tracking: tracking.total
    }
  });
}));

// Local database diagnostic: lists table names and required-table availability (no customer data).
app.get("/api/db-info", wrap(async (req, res) => {
  const [[dbRow]] = await db.query("SELECT DATABASE() AS databaseName");
  const [tableRows] = await db.query(
    `SELECT TABLE_NAME AS tableName
     FROM information_schema.tables
     WHERE table_schema = DATABASE()
     ORDER BY TABLE_NAME`
  );
  const tables = tableRows.map(row => row.tableName);
  res.json({
    success: true,
    database: dbRow.databaseName,
    tables,
    requiredTables: {
      customers: tables.includes("customers"),
      parcels: tables.includes("parcels"),
      tracking: tables.includes("tracking")
    },
    note: "The application displays records from customers, parcels and tracking in the selected database."
  });
}));

// CUSTOMER CRUD
app.get("/api/customers", wrap(async (req, res) => {
  const [rows] = await db.query("SELECT * FROM customers ORDER BY customer_id DESC");
  res.json(rows);
}));

app.get("/api/customers/:id", wrap(async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid customer ID" });
  const [rows] = await db.execute("SELECT * FROM customers WHERE customer_id = ?", [req.params.id]);
  if (!rows.length) return res.status(404).json({ message: "Customer not found" });
  res.json(rows[0]);
}));

app.post("/api/customers", wrap(async (req, res) => {
  const { customer_name, phone, email, address, city } = req.body;
  if (![customer_name, phone, address].every(v => String(v || "").trim())) {
    return res.status(400).json({ message: "Name, phone and address are required." });
  }
  const [r] = await db.execute(
    "INSERT INTO customers(customer_name, phone, email, address, city) VALUES(?,?,?,?,?)",
    [customer_name.trim(), phone.trim(), email || null, address.trim(), city || null]
  );
  res.status(201).json({ success: true, customer_id: r.insertId, message: "Customer added successfully." });
}));

app.put("/api/customers/:id", wrap(async (req, res) => {
  const { customer_name, phone, email, address, city } = req.body;
  if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid customer ID" });
  if (![customer_name, phone, address].every(v => String(v || "").trim())) {
    return res.status(400).json({ message: "Name, phone and address are required." });
  }
  const [r] = await db.execute(
    "UPDATE customers SET customer_name=?, phone=?, email=?, address=?, city=? WHERE customer_id=?",
    [customer_name.trim(), phone.trim(), email || null, address.trim(), city || null, req.params.id]
  );
  if (!r.affectedRows) return res.status(404).json({ message: "Customer not found" });
  res.json({ success: true, message: "Customer updated successfully." });
}));

app.delete("/api/customers/:id", wrap(async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid customer ID" });
  try {
    const [r] = await db.execute("DELETE FROM customers WHERE customer_id=?", [req.params.id]);
    if (!r.affectedRows) return res.status(404).json({ message: "Customer not found" });
    res.json({ success: true, message: "Customer deleted." });
  } catch (e) {
    if (e.code === "ER_ROW_IS_REFERENCED_2") {
      return res.status(409).json({ message: "This customer has parcels. Delete or reassign those parcels before deleting the customer." });
    }
    throw e;
  }
}));

// PARCEL BOOKING + LIST
app.get("/api/parcels", wrap(async (req, res) => {
  const [rows] = await db.query(
    `SELECT p.*, c.customer_name, c.phone AS sender_phone
     FROM parcels p JOIN customers c ON p.customer_id=c.customer_id
     ORDER BY p.parcel_id DESC`
  );
  res.json(rows);
}));

app.get("/api/parcels/:tracking", wrap(async (req, res) => {
  const [rows] = await db.execute(
    `SELECT p.*, c.customer_name, c.phone AS sender_phone, c.email
     FROM parcels p JOIN customers c ON p.customer_id=c.customer_id
     WHERE p.tracking_number=?`,
    [req.params.tracking]
  );
  if (!rows.length) return res.status(404).json({ message: "No parcel found for this tracking number." });
  const [events] = await db.execute(
    "SELECT * FROM tracking WHERE parcel_id=? ORDER BY update_time DESC",
    [rows[0].parcel_id]
  );
  res.json({ parcel: rows[0], events });
}));

app.post("/api/parcels", wrap(async (req, res) => {
  const b = req.body;
  if (![b.customer_id, b.receiver_name, b.receiver_phone, b.pickup_address,
        b.delivery_address, b.origin, b.destination].every(v => String(v || "").trim())) {
    return res.status(400).json({ message: "Please fill all required parcel details." });
  }

  const tracking_number = "MH" + Date.now().toString().slice(-9) + Math.floor(10 + Math.random() * 90);
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [r] = await conn.execute(
      `INSERT INTO parcels
       (tracking_number, customer_id, receiver_name, receiver_phone, pickup_address,
        delivery_address, origin, destination, parcel_type, weight, amount, current_status)
       VALUES(?,?,?,?,?,?,?,?,?,?,?,'Booked')`,
      [tracking_number, b.customer_id, b.receiver_name.trim(), b.receiver_phone.trim(),
       b.pickup_address.trim(), b.delivery_address.trim(), b.origin.trim(), b.destination.trim(),
       b.parcel_type || "Package", Number(b.weight) || 0.5, Number(b.amount) || 0]
    );
    await conn.execute(
      "INSERT INTO tracking(parcel_id,status,current_location,remarks) VALUES(?,?,?,?)",
      [r.insertId, "Booked", b.origin.trim(), "Parcel booking created."]
    );
    await conn.commit();
    res.status(201).json({ success: true, tracking_number, message: "Parcel booked successfully." });
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}));

// TRACKING EVENT UPDATE
app.post("/api/tracking", wrap(async (req, res) => {
  const { parcel_id, status, current_location, remarks } = req.body;
  const allowed = ["Booked", "Picked Up", "In Transit", "Out for Delivery", "Delivered", "On Hold", "Cancelled"];
  if (!validId(parcel_id) || !allowed.includes(status) || !String(current_location || "").trim()) {
    return res.status(400).json({ message: "Select a parcel, valid status and current location." });
  }
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [r] = await conn.execute("UPDATE parcels SET current_status=? WHERE parcel_id=?", [status, parcel_id]);
    if (!r.affectedRows) {
      await conn.rollback();
      return res.status(404).json({ message: "Parcel not found." });
    }
    await conn.execute(
      "INSERT INTO tracking(parcel_id,status,current_location,remarks) VALUES(?,?,?,?)",
      [parcel_id, status, current_location.trim(), remarks || `Parcel status changed to ${status}.`]
    );
    await conn.commit();
    res.json({ success: true, message: "Tracking information updated." });
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}));

app.get("/api/summary", wrap(async (req, res) => {
  const [[a]] = await db.query("SELECT COUNT(*) AS total FROM customers");
  const [[b]] = await db.query("SELECT COUNT(*) AS total FROM parcels");
  const [[c]] = await db.query("SELECT COUNT(*) AS total FROM parcels WHERE current_status='Delivered'");
  const [[d]] = await db.query(
    "SELECT COUNT(*) AS total FROM parcels WHERE current_status IN ('Booked','Picked Up','In Transit','Out for Delivery')"
  );
  res.json({ customers: a.total, parcels: b.total, delivered: c.total, active: d.total });
}));

app.use((err, req, res, next) => {
  console.error("API/database error:", err.code || "", err.sqlMessage || err.message || err);
  let message = "Server/database error. Check the VS Code terminal.";
  if (err.code === "ER_ACCESS_DENIED_ERROR") {
    message = "MySQL login failed. Check DB_USER and DB_PASSWORD in the .env file.";
  } else if (err.code === "ER_BAD_DB_ERROR") {
    message = `Database '${process.env.DB_NAME || "courier_management"}' does not exist. Run the supplied SQL file or correct DB_NAME in .env.`;
  } else if (err.code === "ER_NO_SUCH_TABLE") {
    message = `A required table is missing in '${process.env.DB_NAME || "courier_management"}'. Check /api/db-info and run sql/courier_management.sql only if this is a new project database.`;
  } else if (err.code === "ER_BAD_FIELD_ERROR") {
    message = "The selected database has a table with different column names from this project. Check /api/db-info and compare its table structure with sql/courier_management.sql.";
  } else if (err.code === "ECONNREFUSED") {
    message = "Cannot reach MySQL. Start the MySQL80 service and try again.";
  }
  res.status(500).json({ message });
});

// Verify connection as soon as the server starts.
app.listen(PORT, async () => {
  console.log(`Courier Management System running at http://localhost:${PORT}`);
  try {
    await db.query("SELECT 1");
    console.log(`MySQL connected. Database: ${process.env.DB_NAME || "courier_management"}`);
  } catch (err) {
    console.error("MySQL connection failed:", err.code || "", err.message);
    console.error("Check MySQL is running and DB_HOST, DB_USER, DB_PASSWORD, DB_NAME in .env are correct.");
  }
});
